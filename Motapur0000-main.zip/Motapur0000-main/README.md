<!DOCTYPE html>
<html>

<head>
    <title>Welcome to Motapur - The Martian Country</title>
</head>

<body>

    <header>
        <h1>Welcome to Motapur</h1>
    </header>

    <section>
        <h2>Let Us Change Our Characters</h2>
        <ul>
            <li>Motapur is basically a country on Mars.</li>
            <li>(Yes... Haters will say it's fake. If you're in doubt, go and check on Mars that it exists or not; we're not visible on cameras.)</li>
            <li>Motapur is a fascinating part of northern Mars.</li>
            <li>Motapur is proudly owned and led by Raju ji and Mota ji.</li>
            <li>It boasts the largest economy sector on Mars with a per capita income of Я100,000.</li>
            <li>If you're wondering what is "Я", this is a currency of Motapur called "Rokda" denoted by "Я".</li>
            <li>Motapur is the capital (Rajdhani) of Mars, making it a centered and strategic location.</li>
            <li>We have an efficient Transportation system connecting Motapur (Mars) with Earth.</li>
        </ul>
    </section>

    <footer>
        <p>Explore more about Motapur and its wonders!</p>
    </footer>

</body>

</html>
